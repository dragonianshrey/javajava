package com.example.demoMysqlApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMysqlApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
