package com.example.demoMysqlApi.Repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demoMysqlApi.Model.Student;

public interface StudentRepo extends CrudRepository<Student, Integer>{

}