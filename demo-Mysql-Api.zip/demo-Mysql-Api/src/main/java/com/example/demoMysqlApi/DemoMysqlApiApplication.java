package com.example.demoMysqlApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMysqlApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMysqlApiApplication.class, args);
	}

}
